package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccessibility : AccessibilityService() {
    companion object {
        @Volatile var pending: String? = null
        @Volatile var pendingAt: Long = 0
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val mode = pending ?: return
        if (System.currentTimeMillis() - pendingAt > 20000) { pending = null; return }
        if (e?.packageName?.toString() != "com.google.android.youtube") return
        val root = rootInActiveWindow ?: return
        val done = if (mode == "subscribe") trySubscribe(root) else tryPlay(root)
        if (done) pending = null
    }

    private fun click(n: AccessibilityNodeInfo?): Boolean {
        var x = n
        while (x != null) {
            if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            x = x.parent
        }
        return false
    }

    private fun trySubscribe(root: AccessibilityNodeInfo): Boolean {
        for (label in listOf("Subscribe", "सब्सक्राइब करें")) {
            for (n in root.findAccessibilityNodeInfosByText(label)) {
                val s = (n.text ?: n.contentDescription)?.toString()?.trim() ?: continue
                if (s.equals("Subscribe", true) || s == "सब्सक्राइब करें" || s.startsWith("Subscribe to", true)) {
                    if (click(n)) return true
                }
            }
        }
        return false
    }

    private fun tryPlay(root: AccessibilityNodeInfo): Boolean {
        val hits = root.findAccessibilityNodeInfosByText("Play video")
        for (n in hits) if (click(n)) return true
        return false
    }
}
