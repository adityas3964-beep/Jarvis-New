package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.util.Locale
import java.util.zip.ZipInputStream
import org.vosk.android.RecognitionListener as VoskListener

class JarvisService : Service() {
    private var model: Model? = null
    private var speech: SpeechService? = null
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var busy = false
    private var listening = false
    private var dead = false
    private var loading = false
    private val timeout = Runnable { finishListen(null) }

    companion object {
        const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis sun raha hai")
            .setContentText("Bolo: Jarvis ...")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN") }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startWake()
        return START_STICKY
    }

    private fun toast(t: String) { handler.post { Toast.makeText(this, t, Toast.LENGTH_LONG).show() } }

    // Model ek baar download hota hai (filesDir/vosk), phir offline chalta hai.
    private fun ensureModel(): File {
        val root = File(filesDir, "vosk")
        val done = File(root, ".done")
        if (done.exists()) {
            root.listFiles()?.firstOrNull { it.isDirectory }?.let { return it }
        }
        toast("Pehli baar: wake-word model download ho raha hai (~40MB), wait karo...")
        root.deleteRecursively()
        root.mkdirs()
        val conn = URL(MODEL_URL).openConnection().apply { connectTimeout = 15000; readTimeout = 30000 }
        ZipInputStream(conn.getInputStream().buffered()).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                val out = File(root, e.name)
                if (!out.canonicalPath.startsWith(root.canonicalPath)) throw SecurityException("bad zip entry")
                if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zis.copyTo(it) }
                }
                e = zis.nextEntry
            }
        }
        done.writeText("ok")
        return root.listFiles()!!.first { it.isDirectory }
    }

    private fun startWake() {
        if (model != null) { beginWake(); return }
        if (loading) return
        loading = true
        Thread {
            try {
                val dir = ensureModel()
                val m = Model(dir.absolutePath)
                handler.post {
                    loading = false
                    if (dead) { m.close() } else { model = m; beginWake() }
                }
            } catch (e: Exception) {
                loading = false
                toast("Model error: " + e.message + " (internet check karo)")
                handler.post { stopSelf() }
            }
        }.start()
    }

    private val wakeListener = object : VoskListener {
        override fun onPartialResult(h: String?) { check(h) }
        override fun onResult(h: String?) { check(h) }
        override fun onFinalResult(h: String?) {}
        override fun onError(e: Exception?) {}
        override fun onTimeout() {}
    }

    private fun check(h: String?) {
        if (!busy && h != null && h.contains("jarvis")) onWake()
    }

    private fun beginWake() {
        if (dead) return
        try {
            val rec = Recognizer(model, 16000.0f, "[\"jarvis\", \"[unk]\"]")
            speech = SpeechService(rec, 16000.0f)
            speech?.startListening(wakeListener)
        } catch (e: Exception) {
            toast("Wake word error: " + e.message)
            stopSelf()
        }
    }

    private fun stopWake() {
        try { speech?.stop() } catch (e: Exception) {}
        try { speech?.shutdown() } catch (e: Exception) {}
        speech = null
    }

    private fun say(t: String) { tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j") }

    private fun onWake() {
        if (busy) return
        busy = true
        stopWake()
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150) } catch (e: Exception) {}
        handler.postDelayed({ listen() }, 450)
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Speech service nahi mila"); resume(); return
        }
        val lang = getSharedPreferences("jarvis", MODE_PRIVATE).getString("lang", "hi-IN")
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        listening = true
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onError(e: Int) { finishListen(null) }
            override fun onResults(res: Bundle?) {
                finishListen(res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull())
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        r.startListening(i)
        handler.postDelayed(timeout, 12000)
    }

    private fun finishListen(text: String?) {
        if (!listening) return
        listening = false
        handler.removeCallbacks(timeout)
        try { recognizer?.destroy() } catch (e: Exception) {}
        recognizer = null
        if (!text.isNullOrBlank()) Commands.run(this, text) { say(it) }
        handler.postDelayed({ resume() }, 3000)
    }

    private fun resume() {
        busy = false
        beginWake()
    }

    override fun onDestroy() {
        dead = true
        handler.removeCallbacksAndMessages(null)
        stopWake()
        try { model?.close() } catch (e: Exception) {}
        try { recognizer?.destroy() } catch (e: Exception) {}
        tts?.shutdown()
        super.onDestroy()
    }
}
