package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("jarvis", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        val sv = ScrollView(this); sv.addView(root); setContentView(sv)

        fun btn(t: String, f: () -> Unit): Button {
            val bt = Button(this).apply { text = t; setOnClickListener { f() } }
            root.addView(bt); return bt
        }

        root.addView(TextView(this).apply { text = "JARVIS"; textSize = 30f })
        root.addView(TextView(this).apply { text = "Wake word: Jarvis (Vosk, bina AccessKey ke). Pehli baar ~40MB model download hoga." })

        btn("1. Permissions do") {
            requestPermissions(arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.POST_NOTIFICATIONS,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS), 1)
        }
        btn("2. Display over other apps: ON") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("3. Accessibility mein Jarvis: ON") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("4. Battery: Unrestricted") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        lateinit var langBtn: Button
        fun updLang() { langBtn.text = "Bolne ki bhasha: " + if (p.getString("lang", "hi-IN") == "hi-IN") "Hindi" else "English" }
        langBtn = btn("") {
            val n = if (p.getString("lang", "hi-IN") == "hi-IN") "en-IN" else "hi-IN"
            p.edit().putString("lang", n).apply(); updLang()
        }
        updLang()

        btn("▶ START JARVIS") {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Pehle step 1 karo", Toast.LENGTH_LONG).show()
            } else {
                startForegroundService(Intent(this, JarvisService::class.java))
                Toast.makeText(this, "Jarvis chalu. Bolo: Jarvis...", Toast.LENGTH_LONG).show()
            }
        }
        btn("■ STOP") { stopService(Intent(this, JarvisService::class.java)) }
    }
}
